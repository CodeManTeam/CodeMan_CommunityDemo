from models import User, db
from crypto_utils import decrypt_data
import sys

def show_credentials():
    if db.is_closed():
        db.connect()
    
    print("="*60)
    print("      ENCRYPTED CREDENTIAL MANAGER (ADMIN ONLY)")
    print("="*60)
    print("WARNING: These are sensitive credentials.")
    print("Ensure no unauthorized persons are looking at your screen.")
    print("-" * 60)
    
    users = User.select().where(User.encrypted_password.is_null(False))
    
    if users.count() == 0:
        print("No credentials stored yet.")
        return

    print(f"{'User':<20} | {'Login ID':<20} | {'Password (Decrypted)':<20}")
    print("-" * 60)
    
    for user in users:
        try:
            pwd = decrypt_data(user.encrypted_password)
            if not pwd:
                pwd = "[Decryption Failed]"
        except Exception:
            pwd = "[Error]"
            
        print(f"{user.username:<20} | {user.login_identity:<20} | {pwd:<20}")

    print("-" * 60)

if __name__ == "__main__":
    show_credentials()
