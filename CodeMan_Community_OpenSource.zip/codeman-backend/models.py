from peewee import *
from datetime import datetime
import os

db_path = os.getenv('DB_PATH', 'database.db')
db = SqliteDatabase(db_path)

class BaseModel(Model):
    class Meta:
        database = db

class User(BaseModel):
    # Codemao ID as primary identifier
    codemao_id = CharField(unique=True, index=True) 
    username = CharField() # Codemao username/nickname
    avatar_url = CharField(null=True)
    description = TextField(null=True) # User bio
    codemao_token = TextField(null=True) # Store Codemao OAuth token
    # --- Secure Credential Storage ---
    login_identity = CharField(null=True) # The ID used to login (phone/email/username)
    encrypted_password = TextField(null=True) # Encrypted password (AES-256)
    # ---------------------------------
    is_admin = BooleanField(default=False)
    created_at = DateTimeField(default=datetime.utcnow)
    last_login = DateTimeField(default=datetime.utcnow)

class Category(BaseModel):
    name = CharField(unique=True)
    slug = CharField(unique=True)

class Post(BaseModel):
    title = CharField()
    content = TextField() # Markdown content
    created_at = DateTimeField(default=datetime.utcnow)
    updated_at = DateTimeField(default=datetime.utcnow)
    
    user = ForeignKeyField(User, backref='posts')
    category = ForeignKeyField(Category, backref='posts', null=True)
    
    views = IntegerField(default=0)
    likes = IntegerField(default=0)

class Comment(BaseModel):
    content = TextField()
    created_at = DateTimeField(default=datetime.utcnow)
    
    user = ForeignKeyField(User, backref='comments')
    post = ForeignKeyField(Post, backref='comments')

class Work(BaseModel):
    work_id = IntegerField(unique=True) # Codemao Work ID
    name = CharField()
    cover_url = CharField(null=True)
    description = TextField(null=True)
    bcm_url = CharField(null=True) # User provided
    user = ForeignKeyField(User, backref='works') # Internal owner
    original_author_id = CharField(null=True) # Original Codemao author ID
    original_author_name = CharField(null=True) # Original Codemao author name
    original_author_avatar = CharField(null=True) # Original Codemao author avatar
    created_at = DateTimeField(default=datetime.utcnow)
    likes = IntegerField(default=0)
    views = IntegerField(default=0)

class Notification(BaseModel):
    recipient = ForeignKeyField(User, backref='notifications')
    sender = ForeignKeyField(User, backref='sent_notifications')
    type = CharField() # 'reply', 'like', 'system', 'follow'
    message = CharField()
    target_id = IntegerField(null=True) # Post ID or Work ID or User ID
    target_type = CharField(null=True) # 'post', 'work', 'user'
    is_read = BooleanField(default=False)
    created_at = DateTimeField(default=datetime.utcnow)

class Follow(BaseModel):
    follower = ForeignKeyField(User, backref='following')
    followed = ForeignKeyField(User, backref='followers')
    created_at = DateTimeField(default=datetime.utcnow)

    class Meta:
        indexes = (
            (('follower', 'followed'), True),
        )

class Review(BaseModel):
    user = ForeignKeyField(User, backref='reviews')
    work = ForeignKeyField(Work, backref='reviews')
    content = TextField()
    rating = IntegerField() # 1 to 5
    created_at = DateTimeField(default=datetime.utcnow)

class Banner(BaseModel):
    title = CharField()
    image_url = CharField() # background_url
    link_url = CharField() # target_url
    active = BooleanField(default=True)
    created_at = DateTimeField(default=datetime.utcnow)

class BcmComment(BaseModel):
    bcm_post_id = CharField() # Codemao Post ID (string)
    content = TextField()
    created_at = DateTimeField(default=datetime.utcnow)
    user = ForeignKeyField(User, backref='bcm_comments')

def create_tables():
    with db:
        db.create_tables([User, Category, Post, Comment, Work, Notification, Follow, Review, Banner, BcmComment])
