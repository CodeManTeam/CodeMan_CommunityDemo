import json
import os
from typing import List, Optional
from fastapi import APIRouter, Query, HTTPException, Request, Depends
from pydantic import BaseModel
import httpx
from models import Work, User, Review, Notification
from security import get_current_user
from peewee import fn

router = APIRouter()

# Load works data
WORKS_DATA = []
try:
    # Works data is in the same directory as main.py (parent of routers)
    # Assuming execution from codeman-backend/
    with open("output_works_5000.json", "r", encoding="utf-8") as f:
        WORKS_DATA = json.load(f)
except Exception as e:
    print(f"Error loading works data: {e}")

class WorkSubmission(BaseModel):
    work_id: int
    bcm_url: str

class ReviewCreate(BaseModel):
    content: str
    rating: int

@router.get("/works")
def get_works(skip: int = 0, limit: int = 20):
    # Combine DB works and JSON works
    # Priority: DB Works (newest first) -> JSON Works
    
    # Fetch from DB (Join with User to get uploader info)
    # We need to manually construct the dictionary because .dicts() flattens joins in a way that might overwrite ID
    works_query = (Work.select(Work, User)
                   .join(User)
                   .order_by(Work.created_at.desc()))
    
    db_works = []
    for w in works_query:
        # Use original author info if system-owned work
        if w.user.codemao_id == "0" and w.original_author_id:
            display_nickname = w.original_author_name or "Original Developer"
            display_avatar = w.original_author_avatar
            display_user_id = w.original_author_id
        else:
            display_nickname = w.user.username
            display_avatar = w.user.avatar_url
            display_user_id = w.user.codemao_id

        db_works.append({
            "work_id": w.work_id,
            "work_name": w.name,
            "preview_url": w.cover_url,
            "description": w.description,
            "bcm_url": w.bcm_url,
            "likes_count": w.likes,
            "views_count": w.views,
            "avatar_url": display_avatar,
            "nickname": display_nickname,
            "user_id": display_user_id,
            "internal_user_id": w.user.id if w.user.codemao_id != "0" else None
        })
    
    # Deduplicate: Only add JSON works that are not in DB
    existing_ids = {w["work_id"] for w in db_works}
    
    filtered_json_works = []
    for w in WORKS_DATA:
        # JSON work_id might be string or int, normalize to match DB
        # Assuming DB work_id is int, and JSON is int
        if w["work_id"] not in existing_ids:
            filtered_json_works.append(w)
            
    # Combine
    combined = db_works + filtered_json_works
    
    return combined[skip : skip + limit]

def get_work_details(work_id: int):
    # 1. Try DB
    try:
        w = Work.select(Work, User).join(User).where(Work.work_id == work_id).get()
        
        # Get Reviews
        reviews = (Review.select(Review, User)
                   .join(User)
                   .where(Review.work == w)
                   .order_by(Review.created_at.desc()))
                   
        reviews_data = [{
            "id": r.id,
            "user": {
                "username": r.user.username,
                "avatar_url": r.user.avatar_url,
                "id": r.user.id
            },
            "content": r.content,
            "rating": r.rating,
            "created_at": r.created_at
        } for r in reviews]
        
        avg_rating = reviews.select(fn.AVG(Review.rating)).scalar() or 0
        
        # Use original author info if this is a system-owned work
        if w.user.codemao_id == "0" and w.original_author_id:
            display_nickname = w.original_author_name or "Original Developer"
            display_avatar = w.original_author_avatar
            display_user_id = w.original_author_id
        else:
            display_nickname = w.user.username
            display_avatar = w.user.avatar_url
            display_user_id = w.user.codemao_id
            
        return {
            "work_id": w.work_id,
            "work_name": w.name,
            "preview_url": w.cover_url,
            "description": w.description,
            "bcm_url": w.bcm_url,
            "likes_count": w.likes,
            "views_count": w.views,
            "avatar_url": display_avatar,
            "nickname": display_nickname,
            "user_id": display_user_id,
            "reviews": reviews_data,
            "rating": round(float(avg_rating), 1),
            "review_count": len(reviews_data),
            "internal_user_id": w.user.id if w.user.codemao_id != "0" else None
        }
    except Work.DoesNotExist:
        pass
        
    # 2. Try JSON
    for w in WORKS_DATA:
        if str(w.get('work_id')) == str(work_id):
            # For JSON works, no reviews initially
            w_copy = w.copy()
            w_copy["reviews"] = []
            w_copy["rating"] = 0
            w_copy["review_count"] = 0
            return w_copy
            
    return None

@router.get("/works/user-codemao-works")
async def get_user_codemao_works(request: Request, current_user: User = Depends(get_current_user)):
    # Fetch recent works from Codemao API
    # https://api.codemao.cn/creation-tools/v2/user/center/work-list?type=newest&user_id={id}&offset=0&limit=20
    api_url = f"https://api.codemao.cn/creation-tools/v2/user/center/work-list"
    params = {
        "type": "newest",
        "user_id": current_user.codemao_id,
        "offset": 0,
        "limit": 20
    }
    
    async with httpx.AsyncClient() as client:
        try:
            resp = await client.get(api_url, params=params)
            if resp.status_code != 200:
                print(f"Codemao API Error: {resp.status_code} {resp.text}")
                return {"items": []} # Return empty list on error
            return resp.json()
        except Exception as e:
            print(f"Fetch User Works Error: {e}")
            return {"items": []}

@router.get("/works/search")
def search_works(q: str = Query(..., min_length=1)):
    # Search in DB
    db_query = (Work.select(Work, User)
                .join(User)
                .where(Work.name.contains(q)))
    
    db_results = []
    for w in db_query:
        db_results.append({
            "work_id": w.work_id,
            "work_name": w.name,
            "preview_url": w.cover_url,
            "description": w.description,
            "bcm_url": w.bcm_url,
            "likes_count": w.likes,
            "views_count": w.views,
            "avatar_url": w.user.avatar_url,
            "nickname": w.user.username,
            "user_id": w.user.codemao_id 
        })
    
    # Search in JSON
    json_results = [
        w for w in WORKS_DATA 
        if q.lower() in w['work_name'].lower() or q.lower() in w['nickname'].lower()
    ]
    
    return (db_results + json_results)[:50]

import nh3

# ... (existing imports)

# ...

@router.get("/works/{work_id}")
async def get_work_info(work_id: int):
    info = get_work_details(work_id)
    if not info:
        # Fallback: Fetch from live Codemao API
        try:
            api_url = f"https://api.codemao.cn/creation-tools/v1/works/{work_id}"
            async with httpx.AsyncClient() as client:
                resp = await client.get(api_url)
                if resp.status_code == 200:
                    data = resp.json()
                    # Convert Codemao API format to our internal format
                    result = {
                        "work_id": data.get("id"),
                        "work_name": data.get("work_name"),
                        "preview_url": data.get("preview"),
                        "description": data.get("description"),
                        "bcm_url": None, # Live works don't have bcm_url unless in our DB
                        "likes_count": data.get("praise_times", 0),
                        "views_count": data.get("view_times", 0),
                        "collect_times": data.get("collect_times", 0),
                        "share_times": data.get("share_times", 0),
                        "comment_times": data.get("comment_times", 0),
                        "publish_time": data.get("publish_time"),
                        "avatar_url": data.get("user_info", {}).get("avatar"),
                        "nickname": data.get("user_info", {}).get("nickname"),
                        "user_id": str(data.get("user_info", {}).get("id")),
                        "player_url": data.get("player_url", "").strip(),
                        "share_url": data.get("share_url", "").strip(),
                        "reviews": [], # Live works don't have our internal reviews
                        "rating": 0,
                        "review_count": 0,
                        "is_live": True # Flag to indicate this is fetched live
                    }
                    
                    # Try to find if this Codemao user exists in our DB
                    internal_user = User.get_or_none(User.codemao_id == result["user_id"])
                    if internal_user:
                        result["internal_user_id"] = internal_user.id
                        
                    return result
        except Exception as e:
            print(f"Live fetch error: {e}")
            
        raise HTTPException(status_code=404, detail="Work not found")
    return info

@router.get("/works/{work_id}/codemao_comments")
async def get_codemao_comments(work_id: int, limit: int = 20, offset: int = 0):
    """
    Fetch comments from Codemao official work page
    """
    url = f"https://api.codemao.cn/creation-tools/v1/works/{work_id}/comments"
    params = {
        "limit": limit,
        "offset": offset
    }
    
    async with httpx.AsyncClient() as client:
        try:
            resp = await client.get(url, params=params)
            if resp.status_code != 200:
                return []
            
            data = resp.json()
            items = data.get("items", [])
            
            comments = []
            for item in items:
                user_data = item.get("user", {})
                content = item.get("content", "")
                # Sanitize content
                safe_content = nh3.clean(content, tags={'b', 'i', 'u', 'em', 'strong'})
                
                comments.append({
                    "id": str(item.get("id")),
                    "content": safe_content,
                    "user": {
                        "id": str(user_data.get("id")),
                        "nickname": user_data.get("nickname"),
                        "avatar_url": user_data.get("avatar_url")
                    },
                    "created_at": item.get("created_at")
                })
            return comments
        except Exception as e:
            print(f"Error fetching Codemao work comments: {e}")
            return []

@router.post("/works/{work_id}/reviews")
async def create_review(work_id: int, review: ReviewCreate, request: Request, current_user: User = Depends(get_current_user)):
    # First, try to find the work in our DB
    try:
        work = Work.get(Work.work_id == work_id)
    except Work.DoesNotExist:
        # If it doesn't exist in DB (it's a 'live' work), auto-claim it!
        # Fetch details from Codemao API to create the work record
        try:
            api_url = f"https://api.codemao.cn/creation-tools/v1/works/{work_id}"
            async with httpx.AsyncClient() as client:
                resp = await client.get(api_url)
                if resp.status_code != 200:
                    raise HTTPException(status_code=404, detail="Work not found on Codemao")
                
                data = resp.json()
                # Create the work in DB, assigned to the original author if possible, or a placeholder?
                # Ideally we want to link to the correct internal user if they exist.
                
                work_owner_id = str(data.get("user_info", {}).get("id"))
                work_owner_nickname = data.get("user_info", {}).get("nickname", "Unknown Developer")
                work_owner_avatar = data.get("user_info", {}).get("avatar", "")
                
                internal_owner = User.get_or_none(User.codemao_id == work_owner_id)
                
                if not internal_owner:
                    # If the author isn't on CodeMan, we can't assign it to them yet.
                    # But we want to preserve the original author information.
                    # We'll create a system user that represents "external works" but preserves author info.
                    
                    # Create/get a system user for external works
                    system_user, _ = User.get_or_create(
                        codemao_id="0", 
                        defaults={"username": "Codemao System", "password_hash": "sys", "avatar_url": ""}
                    )
                    internal_owner = system_user

                work = Work.create(
                    work_id=work_id,
                    name=data["work_name"],
                    cover_url=data["preview"],
                    description=data["description"],
                    bcm_url="", # No BCM source yet
                    user=internal_owner,
                    original_author_id=work_owner_id,
                    original_author_name=work_owner_nickname,
                    original_author_avatar=work_owner_avatar,
                    likes=data["praise_times"],
                    views=data["view_times"]
                )
                
        except Exception as e:
            print(f"Auto-claim failed: {e}")
            raise HTTPException(status_code=500, detail="Failed to initialize review section for this work")

    # Check if already reviewed
    if Review.select().where((Review.user == current_user) & (Review.work == work)).exists():
        raise HTTPException(status_code=400, detail="You have already reviewed this work")

    if review.rating < 1 or review.rating > 5:
        raise HTTPException(status_code=400, detail="Rating must be between 1 and 5")

    new_review = Review.create(
        user=current_user,
        work=work,
        content=review.content,
        rating=review.rating
    )
    
    # Notify Owner (only if it's a real user)
    if work.user.id != current_user.id and work.user.codemao_id != "0":
        Notification.create(
            recipient=work.user,
            sender=current_user,
            type="review",
            message=f"reviewed your work: {work.name}",
            target_id=work.work_id,
            target_type="work"
        )
        
    return {
        "id": new_review.id,
        "user": {
            "username": current_user.username,
            "avatar_url": current_user.avatar_url
        },
        "content": new_review.content,
        "rating": new_review.rating,
        "created_at": new_review.created_at
    }

@router.get("/works/{work_id}/source")
async def get_source_code(work_id: int):
    # Fetch source code info from Codemao Player API
    api_url = f"https://api-creation.codemao.cn/kitten/r2/work/player/load/{work_id}"
    
    async with httpx.AsyncClient() as client:
        try:
            resp = await client.get(api_url)
            if resp.status_code != 200:
                raise HTTPException(status_code=404, detail="Work source not found or private")
            
            data = resp.json()
            source_urls = data.get("source_urls", [])
            
            if not source_urls:
                # Some old works might not have source_urls in this API
                raise HTTPException(status_code=404, detail="No source code available for this work")
                
            return {
                "work_id": work_id,
                "name": data.get("name"),
                "preview": data.get("preview"),
                "source_urls": source_urls,
                "version": data.get("version"),
                "updated_time": data.get("updated_time")
            }
        except httpx.RequestError as e:
            print(f"Source fetch error: {e}")
            raise HTTPException(status_code=500, detail="Failed to connect to Codemao API")
        except Exception as e:
            print(f"Source fetch error: {e}")
            raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/works/submit")
async def submit_work(submission: WorkSubmission, request: Request, current_user: User = Depends(get_current_user)):
    # 1. Fetch Work Info from Codemao
    api_url = f"https://api.codemao.cn/creation-tools/v1/works/{submission.work_id}"
    async with httpx.AsyncClient() as client:
        resp = await client.get(api_url)
        if resp.status_code != 200:
             raise HTTPException(status_code=400, detail="Invalid Work ID or Codemao API error")
        data = resp.json()
    
    # 2. Verify Ownership
    # The API returns 'user_info': {'id': 123, ...}
    work_owner_id = str(data.get("user_info", {}).get("id"))
    
    # Debug log
    print(f"Verifying Work {submission.work_id}: Owner {work_owner_id} vs User {current_user.codemao_id}")
    
    if work_owner_id != current_user.codemao_id:
        raise HTTPException(status_code=403, detail=f"You are not the owner of this work. Please log in with the correct account.")

    # 3. Save to DB
    try:
        work = Work.get(Work.work_id == submission.work_id)
        # Update existing
        work.name = data["work_name"]
        work.cover_url = data["preview"]
        work.description = data["description"]
        work.bcm_url = submission.bcm_url
        work.likes = data["praise_times"]
        work.views = data["view_times"]
        work.save()
        return {"message": "Work updated successfully", "work_id": work.work_id}
    except Work.DoesNotExist:
        # Create new
        Work.create(
            work_id=submission.work_id,
            name=data["work_name"],
            cover_url=data["preview"],
            description=data["description"],
            bcm_url=submission.bcm_url,
            user=current_user,
            likes=data["praise_times"],
            views=data["view_times"]
        )
        return {"message": "Work submitted successfully", "work_id": submission.work_id}
