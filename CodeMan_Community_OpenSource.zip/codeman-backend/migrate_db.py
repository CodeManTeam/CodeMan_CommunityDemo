#!/usr/bin/env python3
"""
Database migration script to add original author fields to Work table
"""

import sqlite3
import os

def migrate_database():
    db_path = "database.db"  # 默认数据库路径
    
    if not os.path.exists(db_path):
        print(f"Database {db_path} not found!")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # 检查是否已经存在新字段
        cursor.execute("PRAGMA table_info(work)")
        columns = [row[1] for row in cursor.fetchall()]
        
        print(f"Current Work table columns: {columns}")
        
        # 添加新字段
        new_fields = [
            ("original_author_id", "TEXT"),
            ("original_author_name", "TEXT"),
            ("original_author_avatar", "TEXT")
        ]
        
        for field_name, field_type in new_fields:
            if field_name not in columns:
                print(f"Adding field: {field_name}")
                cursor.execute(f"ALTER TABLE work ADD COLUMN {field_name} {field_type}")
                print(f"✓ Added {field_name}")
            else:
                print(f"Field {field_name} already exists")
        
        conn.commit()
        print("✓ Database migration completed successfully!")
        return True
        
    except Exception as e:
        print(f"❌ Migration failed: {e}")
        return False
    finally:
        conn.close()

if __name__ == "__main__":
    migrate_database()