import { createApp } from 'vue'
import './style.css'
import App from './App.vue'
import router from './router'
import axios from 'axios'
import { authState, logout } from './store'

// Global Axios Interceptor for 401
axios.interceptors.response.use(
  response => response,
  error => {
    if (error.response && error.response.status === 401) {
      // Token expired
      if (authState.isAuthenticated) {
        // Only trigger if we thought we were logged in
        authState.showLoginModal = true // We need to add this to store
      }
    }
    return Promise.reject(error)
  }
)

const app = createApp(App)
app.use(router)
app.mount('#app')
