<script setup>
import { ref, onMounted, computed } from 'vue'
import axios from 'axios'
import MarkdownEditor from '../components/MarkdownEditor.vue'

// --- State ---
const categories = ref([])
const posts = ref([])
const bcmPosts = ref([]) // State for Codemao posts
const activeTab = ref('community') // 'community' or 'codemao'
const selectedCategory = ref('All')
const loading = ref(false)
const showCreateModal = ref(false)
const page = ref(1)
const bcmPage = ref(0) // Codemao API uses offset, we can track page or offset
const hasMore = ref(true)
const bcmHasMore = ref(true)

// --- Fetch Data ---
const fetchCategories = async () => {
  try {
    const res = await axios.get('/api/categories')
    categories.value = res.data
  } catch (e) {
    console.error("Failed to fetch categories", e)
  }
}

const fetchPosts = async (reset = false) => {
  if (reset) {
    page.value = 1
    posts.value = []
    hasMore.value = true
  }
  
  if (!hasMore.value && !reset) return

  loading.value = true
  try {
    const params = {
      skip: (page.value - 1) * 20,
      limit: 20
    }
    if (selectedCategory.value !== 'All') {
      const cat = categories.value.find(c => c.name === selectedCategory.value)
      if (cat) params.category_id = cat.id
    }
    
    const res = await axios.get('/api/posts', { params })
    if (res.data.length < 20) {
      hasMore.value = false
    }
    
    posts.value = [...posts.value, ...res.data]
    page.value++
  } catch (e) {
    console.error("Failed to fetch posts", e)
  } finally {
    loading.value = false
  }
}

const fetchBcmPosts = async (reset = false) => {
  if (reset) {
    bcmPage.value = 0
    bcmPosts.value = []
    bcmHasMore.value = true
  }
  
  if (!bcmHasMore.value && !reset) return
  
  loading.value = true
  try {
    const limit = 20
    const offset = bcmPage.value * limit
    const res = await axios.get('/api/bcm/posts', {
      params: { limit, offset }
    })
    
    // Debug info
    console.log(`Fetched BCM posts: page=${bcmPage.value}, limit=${limit}, offset=${offset}, items=${res.data.length}`)

    if (res.data.length < limit) {
      bcmHasMore.value = false
    }
    
    // Filter out duplicates based on ID
    const newPosts = res.data.filter(newPost => 
      !bcmPosts.value.some(existingPost => existingPost.id === newPost.id)
    )
    
    bcmPosts.value = [...bcmPosts.value, ...newPosts]
    bcmPage.value++
  } catch (e) {
    console.error("Failed to fetch BCM posts", e)
    bcmHasMore.value = false
  } finally {
    loading.value = false
  }
}

const switchTab = (tab) => {
  activeTab.value = tab
  if (tab === 'codemao' && bcmPosts.value.length === 0) {
    fetchBcmPosts(true)
  }
}

// --- Actions ---
const filterPosts = (categoryName) => {
  selectedCategory.value = categoryName
  fetchPosts(true)
}

const handleCreatePost = async () => {
  if (!newPost.value.title || !newPost.value.content || !newPost.value.category_id) {
    alert("Please fill in all fields")
    return
  }
  
  const token = localStorage.getItem('token')
  if (!token) {
    alert("Please login first")
    return
  }

  try {
    await axios.post('/api/posts', newPost.value, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })
    showCreateModal.value = false
    newPost.value = { title: '', content: '', category_id: null }
    fetchPosts(true) // Refresh
  } catch (e) {
    alert("Failed to create post: " + (e.response?.data?.detail || e.message))
  }
}

import { useRouter } from 'vue-router'

const router = useRouter()

// ... (existing code)

const openCodemaoPost = (postId) => {
  router.push(`/forum/bcm/${postId}`)
}

// --- Lifecycle ---
onMounted(async () => {
  await fetchCategories()
  await fetchPosts(true)
})
</script>

<template>
  <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
    <!-- Sidebar: Categories -->
    <div class="md:col-span-1 space-y-6">
      <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 class="text-lg font-bold text-gray-800 mb-4">Categories</h3>
        <ul class="space-y-2">
          <li>
            <button 
              @click="filterPosts('All')"
              class="w-full text-left px-4 py-2 rounded-lg transition-colors"
              :class="selectedCategory === 'All' ? 'bg-blue-50 text-blue-600 font-medium' : 'text-gray-600 hover:bg-gray-50'"
            >
              All Posts
            </button>
          </li>
          <li v-for="cat in categories" :key="cat.id">
            <button 
              @click="filterPosts(cat.name)"
              class="w-full text-left px-4 py-2 rounded-lg transition-colors"
              :class="selectedCategory === cat.name ? 'bg-blue-50 text-blue-600 font-medium' : 'text-gray-600 hover:bg-gray-50'"
            >
              {{ cat.name }}
            </button>
          </li>
        </ul>
      </div>
      
      <button 
        @click="showCreateModal = true"
        class="w-full py-3 bg-blue-600 text-white font-bold rounded-xl shadow-lg hover:bg-blue-700 transition transform hover:-translate-y-1"
      >
        New Post
      </button>
    </div>

    <!-- Main Content: Post List -->
    <div class="md:col-span-3">
      <div class="flex items-center justify-between mb-6">
        <h2 class="text-2xl font-bold text-gray-800">{{ selectedCategory }} Discussions</h2>
        
        <!-- Tabs -->
        <div class="flex bg-gray-100 p-1 rounded-lg">
           <button 
             @click="switchTab('community')"
             class="px-4 py-1.5 rounded-md text-sm font-medium transition"
             :class="activeTab === 'community' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
           >
             Community
           </button>
           <button 
             @click="switchTab('codemao')"
             class="px-4 py-1.5 rounded-md text-sm font-medium transition"
             :class="activeTab === 'codemao' ? 'bg-white text-orange-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
           >
             Codemao Official
           </button>
        </div>
      </div>

      <div v-if="loading && posts.length === 0 && bcmPosts.length === 0" class="text-center py-12 text-gray-500">
        Loading discussions...
      </div>

      <!-- Community Posts List -->
      <div v-if="activeTab === 'community'">
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div v-if="posts.length === 0 && !loading" class="p-12 text-center text-gray-400">
            No posts found in this category. Be the first to start a discussion!
          </div>
          <div 
            v-for="post in posts" 
            :key="post.id" 
            @click="$router.push(`/forum/${post.id}`)"
            class="p-6 border-b border-gray-100 last:border-0 hover:bg-gray-50 transition cursor-pointer group"
          >
            <div class="flex justify-between items-start">
              <div>
                <h3 class="text-xl font-semibold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">{{ post.title }}</h3>
                <p class="text-sm text-gray-500 mb-2">
                  Posted by <span class="font-medium text-gray-700">{{ post.user?.username || 'Unknown' }}</span> 
                  • {{ new Date(post.created_at).toLocaleDateString() }}
                </p>
                <p class="text-gray-600 text-sm line-clamp-2">{{ post.content }}</p>
              </div>
              <div class="flex space-x-4 text-gray-400 text-sm">
                <span class="flex items-center"><span class="mr-1">👁️</span> {{ post.views }}</span>
              </div>
            </div>
          </div>
        </div>
        
        <!-- Load More Button -->
        <div v-if="hasMore" class="p-4 text-center mt-4">
          <button 
            @click="fetchPosts(false)" 
            :disabled="loading"
            class="px-8 py-3 bg-white border border-gray-200 text-gray-600 rounded-full hover:bg-gray-50 hover:border-gray-300 transition shadow-sm text-sm font-medium disabled:opacity-50"
          >
            {{ loading ? 'Loading...' : 'Load More' }}
          </button>
        </div>
      </div>

      <!-- Codemao Posts List -->
      <div v-if="activeTab === 'codemao'">
        <div class="bg-white rounded-xl shadow-sm border border-orange-100 overflow-hidden">
          <div v-if="bcmPosts.length === 0 && !loading" class="p-12 text-center text-gray-400">
            No posts found from Codemao.
          </div>
          <div 
            v-for="post in bcmPosts" 
            :key="post.id" 
            class="p-6 border-b border-gray-100 last:border-0 hover:bg-orange-50 transition cursor-pointer group"
            @click="openCodemaoPost(post.id)"
          >
            <div class="flex justify-between items-start">
              <div>
                <div class="flex items-center space-x-2 mb-1">
                   <span v-if="post.is_top" class="px-1.5 py-0.5 bg-red-100 text-red-600 text-xs font-bold rounded">TOP</span>
                   <span v-if="post.is_hot" class="px-1.5 py-0.5 bg-orange-100 text-orange-600 text-xs font-bold rounded">HOT</span>
                   <h3 class="text-xl font-semibold text-gray-900 group-hover:text-orange-600 transition-colors">{{ post.title }}</h3>
                </div>
                
                <p class="text-sm text-gray-500 mb-2 flex items-center">
                  <img :src="post.user?.avatar_url" class="w-4 h-4 rounded-full mr-1">
                  <span class="font-medium text-gray-700 mr-2">{{ post.user?.nickname || 'Unknown' }}</span> 
                  • {{ new Date(post.created_at * 1000).toLocaleDateString() }}
                </p>
                <p class="text-gray-600 text-sm line-clamp-2" v-html="post.content"></p>
              </div>
              <div class="flex space-x-4 text-gray-400 text-sm">
                <span class="flex items-center" title="Views"><span class="mr-1">👁️</span> {{ post.n_views }}</span>
                <span class="flex items-center" title="Replies"><span class="mr-1">💬</span> {{ post.n_replies }}</span>
              </div>
            </div>
          </div>
        </div>
        
        <!-- Load More Button -->
        <div v-if="bcmHasMore" class="p-4 text-center mt-4">
          <button 
            @click="fetchBcmPosts(false)" 
            :disabled="loading"
            class="px-8 py-3 bg-white border border-orange-200 text-orange-600 rounded-full hover:bg-orange-50 hover:border-orange-300 transition shadow-sm text-sm font-medium disabled:opacity-50"
          >
            {{ loading ? 'Loading...' : 'Load More Codemao Posts' }}
          </button>
        </div>
      </div>
    </div>

    <!-- Create Post Modal -->
    <div v-if="showCreateModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div class="bg-white rounded-2xl w-full max-w-2xl p-8 shadow-2xl">
        <div class="flex justify-between items-center mb-6">
          <h2 class="text-2xl font-bold text-gray-800">Create New Post</h2>
          <button @click="showCreateModal = false" class="text-gray-400 hover:text-gray-600 text-xl">&times;</button>
        </div>
        
        <div class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Title</label>
            <input v-model="newPost.title" type="text" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none">
          </div>
          
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Category</label>
            <select v-model="newPost.category_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none">
              <option :value="null" disabled>Select a category</option>
              <option v-for="cat in categories" :key="cat.id" :value="cat.id">{{ cat.name }}</option>
            </select>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Content</label>
            <MarkdownEditor v-model="newPost.content" height="350px" />
          </div>

          <div class="flex justify-end space-x-4 pt-4">
            <button @click="showCreateModal = false" class="px-6 py-2 text-gray-600 font-medium hover:bg-gray-100 rounded-lg">Cancel</button>
            <button @click="handleCreatePost" class="px-6 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700">Publish</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
