<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import axios from 'axios'
import { authState } from '../store'

const route = useRoute()
const work = ref(null)
const loading = ref(true)
const error = ref('')

// Review/Comment State
const activeTab = ref('community') // 'community' or 'codemao'
const codemaoComments = ref([])
const loadingCodemaoComments = ref(false)
const reviewContent = ref('')
const reviewRating = ref(5)
const submittingReview = ref(false)

const fetchWork = async () => {
  loading.value = true
  try {
    const res = await axios.get(`/api/works/${route.params.id}`)
    work.value = res.data
    
    // Debug log to help track the issue
    if (work.value) {
      console.log('Work data fetched:', {
        nickname: work.value.nickname,
        user_id: work.value.user_id,
        isSystemOwned: work.value.nickname === 'Codemao System' && work.value.user_id === '0'
      })
    }
    
    // Fetch Codemao comments if work is loaded
    if (work.value) {
      fetchCodemaoComments()
    }
  } catch (e) {
    console.error("Failed to fetch work", e)
    error.value = "Work not found"
  } finally {
    loading.value = false
  }
}

const fetchCodemaoComments = async () => {
  loadingCodemaoComments.value = true
  try {
    const res = await axios.get(`/api/works/${work.value.work_id}/codemao_comments`)
    codemaoComments.value = res.data
  } catch (e) {
    console.error("Failed to fetch Codemao comments", e)
  } finally {
    loadingCodemaoComments.value = false
  }
}

const openCodemao = () => {
  if (work.value) {
    window.open(`https://shequ.codemao.cn/work/${work.value.work_id}`, '_blank')
  }
}

const openPlayer = () => {
  if (work.value) {
     window.open(`https://player.codemao.cn/new/${work.value.work_id}`, '_blank')
  }
}

const submitReview = async () => {
  if (!authState.isAuthenticated) {
    alert("Please login to review")
    return
  }
  
  if (!reviewContent.value.trim()) return
  
  submittingReview.value = true
  const token = authState.token || localStorage.getItem('token')
  
  try {
    const res = await axios.post(`/api/works/${work.value.work_id}/reviews`, {
      content: reviewContent.value,
      rating: reviewRating.value
    }, {
      headers: { 'Authorization': `Bearer ${token}` }
    })
    
    // Add new review to list
    if (!work.value.reviews) work.value.reviews = []
    work.value.reviews.unshift(res.data)
    
    // Update stats locally
    const total = work.value.reviews.length
    const sum = work.value.reviews.reduce((acc, r) => acc + r.rating, 0)
    work.value.rating = (sum / total).toFixed(1)
    
    // Reset form
    reviewContent.value = ''
    reviewRating.value = 5
  } catch (e) {
    console.error("Review failed", e)
    alert(e.response?.data?.detail || "Failed to submit review")
  } finally {
    submittingReview.value = false
  }
}

const openSubmitModal = () => {
  // We can reuse the submission logic, but for a specific work
  // For now, let's just use a simple confirm
  if (confirm("Do you want to claim this work and add it to the community database?")) {
    submitWorkClaim()
  }
}

const submitWorkClaim = async () => {
  const token = authState.token || localStorage.getItem('token')
  if (!token) return

  try {
    await axios.post('/api/works/submit', {
      work_id: work.value.work_id,
      bcm_url: '' 
    }, {
      headers: { 'Authorization': `Bearer ${token}` }
    })
    
    alert('Work claimed successfully!')
    fetchWork() // Refresh to get DB version
  } catch (e) {
    alert("Claim failed: " + (e.response?.data?.detail || e.message))
  }
}

const downloadingSource = ref(false)

const downloadSource = async () => {
  // 1. If bcm_url exists, use it directly
  if (work.value.bcm_url) {
    window.open(work.value.bcm_url, '_blank')
    return
  }
  
  // 2. Otherwise try to fetch from Codemao API
  downloadingSource.value = true
  try {
    const res = await axios.get(`/api/works/${work.value.work_id}/source`)
    const sourceUrls = res.data.source_urls
    
    if (sourceUrls && sourceUrls.length > 0) {
      // Open the first source URL
      // TODO: If multiple, maybe show a modal? For now just first one.
      window.open(sourceUrls[0], '_blank')
    } else {
      alert("No source code found for this work.")
    }
  } catch (e) {
    console.error("Failed to download source", e)
    alert("Failed to retrieve source code. It might be private or deleted.")
  } finally {
    downloadingSource.value = false
  }
}

onMounted(() => {
  fetchWork()
})
</script>

<template>
  <div class="container mx-auto px-4 py-8 max-w-5xl">
    <div v-if="loading" class="flex justify-center py-20">
      <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
    </div>

    <div v-else-if="error" class="text-center py-20 text-gray-500">
      {{ error }}
    </div>

    <div v-else class="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <!-- Left: Player/Preview -->
      <div class="lg:col-span-2 space-y-6">
        <div class="aspect-video bg-black rounded-xl overflow-hidden shadow-lg relative group">
          <!-- Embed Player (Using Iframe) -->
          <iframe 
            :src="work.player_url || `https://player.codemao.cn/new/${work.work_id}`"
            class="w-full h-full border-0"
            allowfullscreen
          ></iframe>
        </div>
        
        <div class="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
          <h1 class="text-2xl font-bold text-gray-900 mb-2">{{ work.work_name }}</h1>
          
          <div class="flex flex-wrap items-center gap-4 text-sm text-gray-500 mb-4">
            <span class="flex items-center" title="Views"><span class="mr-1">👁️</span> {{ work.views_count }}</span>
            <span class="flex items-center" title="Likes"><span class="mr-1">❤️</span> {{ work.likes_count }}</span>
            <span class="flex items-center" title="Collects"><span class="mr-1">⭐</span> {{ work.collect_times }}</span>
            <span class="flex items-center" title="Comments"><span class="mr-1">💬</span> {{ work.comment_times }}</span>
             <span v-if="work.is_live" class="px-2 py-0.5 bg-green-100 text-green-700 rounded text-xs font-bold">Live Data</span>
          </div>
          
          <div class="prose prose-sm max-w-none text-gray-700 leading-relaxed whitespace-pre-wrap">
            {{ work.description || 'No description provided.' }}
          </div>
        </div>
      </div>

      <!-- Right: Author & Stats -->
      <div class="lg:col-span-1 space-y-6">
        <!-- Author Card -->
        <div class="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
          <h3 class="font-bold text-gray-400 uppercase text-xs tracking-wide mb-4">Created By</h3>
          <div class="flex items-center space-x-4">
            <img :src="work.avatar_url || 'https://via.placeholder.com/48'" class="w-12 h-12 rounded-full border border-gray-100">
            <div>
              <div class="font-bold text-gray-900">
                {{ work.nickname === 'Codemao System' && work.user_id === '0' ? 'Original Developer' : work.nickname }}
                <span v-if="work.nickname === 'Codemao System' && work.user_id === '0'" class="ml-1 text-gray-400 cursor-help" title="This work was created by a developer on the Codemao platform">ⓘ</span>
              </div>
              <div class="text-xs text-gray-500" v-if="work.user_id !== '0'">ID: {{ work.user_id }}</div>
            </div>
          </div>
          <div class="mt-4 text-xs text-gray-400" v-if="work.publish_time">
            Published on: {{ new Date(work.publish_time * 1000).toLocaleDateString() }}
          </div>
          <div class="mt-6 flex flex-col space-y-2">
            <!-- Internal Profile Link -->
            <router-link 
              v-if="work.internal_user_id" 
              :to="`/user/${work.internal_user_id}`" 
              class="w-full py-2 bg-blue-50 text-blue-600 font-bold rounded-lg hover:bg-blue-100 transition text-center text-sm flex items-center justify-center"
            >
              <span class="mr-1">👤</span> View Community Profile
            </router-link>
            
            <!-- External Profile Link -->
            <a 
              :href="`https://shequ.codemao.cn/user/${work.user_id}`" 
              target="_blank"
              class="w-full py-2 border border-gray-200 text-gray-600 font-bold rounded-lg hover:bg-gray-50 transition text-center text-sm flex items-center justify-center"
            >
              <span class="mr-1">🐱</span> {{ work.nickname === 'Codemao System' && work.user_id === '0' ? 'View Original Profile' : 'View Codemao Profile' }}
            </a>
            
            <!-- Claim Button -->
            <button 
              v-if="work.is_live && authState.user && authState.user.codemao_id === work.user_id"
              @click="openSubmitModal"
              class="w-full py-2 bg-purple-50 text-purple-600 font-bold rounded-lg hover:bg-purple-100 transition text-center text-sm flex items-center justify-center"
            >
              <span class="mr-1">🙋</span> Claim This Work
            </button>
          </div>
        </div>

        <!-- Actions -->
        <div class="bg-white p-6 rounded-xl border border-gray-100 shadow-sm space-y-3">
          <button @click="openPlayer" class="w-full py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition shadow-lg hover:shadow-xl flex items-center justify-center space-x-2">
            <span>Open Player Window</span>
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </button>
        
          <button @click="openCodemao" class="w-full py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition shadow-lg hover:shadow-xl flex items-center justify-center space-x-2">
            <span>View on Codemao</span>
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
            </svg>
          </button>
          
          <div v-if="work.share_url" class="p-3 bg-gray-50 rounded-lg border border-gray-200">
             <div class="text-xs text-gray-500 mb-1 font-bold">Share URL:</div>
             <div class="text-xs text-gray-600 break-all select-all font-mono">{{ work.share_url.replace(/`/g, '') }}</div>
          </div>
          
          <button 
            @click="downloadSource"
            :disabled="downloadingSource"
            class="w-full py-3 bg-green-600 text-white font-bold rounded-xl hover:bg-green-700 transition shadow-lg hover:shadow-xl flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-wait"
          >
            <span v-if="downloadingSource">Fetching Source...</span>
            <span v-else>Download Source (.bcm)</span>
            <svg v-if="!downloadingSource" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
          </button>
        </div>
      </div>
    </div>

    <!-- Reviews Section -->
    <div v-if="!loading && work" class="mt-12 max-w-3xl">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-4">
        <h3 class="text-2xl font-bold text-gray-900 flex items-center">
          Comments
          <span class="ml-3 text-yellow-500 text-lg flex items-center bg-yellow-50 px-3 py-1 rounded-lg shadow-sm" v-if="work.rating > 0">
            <span class="mr-1">★</span> {{ work.rating }}
          </span>
        </h3>
        
        <!-- Tabs -->
        <div class="flex bg-gray-100 p-1 rounded-lg self-start sm:self-auto">
           <button 
             @click="activeTab = 'community'"
             class="px-4 py-1.5 rounded-md text-sm font-medium transition flex items-center"
             :class="activeTab === 'community' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
           >
             Community Reviews <span class="text-xs bg-blue-100 text-blue-600 px-1.5 rounded-full ml-2">{{ work.reviews?.length || 0 }}</span>
           </button>
           <button 
             @click="activeTab = 'codemao'"
             class="px-4 py-1.5 rounded-md text-sm font-medium transition flex items-center"
             :class="activeTab === 'codemao' ? 'bg-white text-orange-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
           >
             Codemao Comments
           </button>
        </div>
      </div>
      
      <!-- Community Reviews -->
      <div v-if="activeTab === 'community'">
        <!-- Review Form -->
        <div v-if="authState.isAuthenticated && !work.is_live" class="mb-8 bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
          <div class="flex items-center mb-4">
             <span class="text-sm font-bold text-gray-700 mr-3">Your Rating:</span>
             <div class="flex space-x-1">
               <button v-for="i in 5" :key="i" @click="reviewRating = i" class="text-2xl focus:outline-none transition transform hover:scale-110" :class="i <= reviewRating ? 'text-yellow-400' : 'text-gray-300'">★</button>
             </div>
          </div>
          <textarea v-model="reviewContent" class="w-full p-4 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-blue-500 outline-none transition bg-gray-50 focus:bg-white" rows="4" placeholder="Write your thoughts about this work..."></textarea>
          <div class="flex justify-end mt-4">
            <button @click="submitReview" :disabled="submittingReview || !reviewContent.trim()" class="px-6 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition disabled:opacity-50 shadow-lg">
              {{ submittingReview ? 'Submitting...' : 'Post Review' }}
            </button>
          </div>
        </div>
        <div v-else-if="work.is_live" class="mb-8 p-6 bg-blue-50 rounded-xl text-blue-700 text-center border border-blue-100">
          Reviews are disabled for live preview works. Please submit this work to CodeMan to enable reviews.
        </div>
        <div v-else class="mb-8 text-center py-8 bg-gray-50 rounded-xl border border-dashed border-gray-300">
          <p class="text-gray-500 mb-2">Join the discussion!</p>
          <router-link to="/login" class="px-6 py-2 bg-white text-blue-600 font-bold rounded-lg border border-blue-200 hover:bg-blue-50 transition inline-block">
            Log in to Review
          </router-link>
        </div>

        <!-- Review List -->
        <div class="space-y-6">
          <div v-if="!work.reviews || work.reviews.length === 0" class="text-center text-gray-400 py-12 bg-white rounded-xl border border-gray-50">
            No reviews yet. Be the first to share your feedback!
          </div>
          <div v-else v-for="review in work.reviews" :key="review.id" class="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition">
            <div class="flex items-start justify-between mb-4">
              <div class="flex items-center space-x-3">
                <img :src="review.user.avatar_url || 'https://via.placeholder.com/40'" class="w-10 h-10 rounded-full border border-gray-100">
                <div>
                  <div class="font-bold text-gray-900">{{ review.user.username }}</div>
                  <div class="text-xs text-gray-400">{{ new Date(review.created_at).toLocaleDateString() }}</div>
                </div>
              </div>
              <div class="flex text-yellow-400 text-sm bg-yellow-50 px-2 py-1 rounded">
                <span v-for="i in 5" :key="i">{{ i <= review.rating ? '★' : '☆' }}</span>
              </div>
            </div>
            <p class="text-gray-700 leading-relaxed whitespace-pre-wrap">{{ review.content }}</p>
          </div>
        </div>
      </div>

      <!-- Codemao Comments -->
      <div v-if="activeTab === 'codemao'">
        <div v-if="loadingCodemaoComments" class="text-center py-12 text-gray-500">
          Loading comments from Codemao...
        </div>
        <div v-else-if="codemaoComments.length === 0" class="text-center py-12 bg-gray-50 rounded-xl text-gray-500 border border-dashed border-gray-200">
          No comments found on Codemao.
        </div>
        <div v-else class="space-y-4">
          <div v-for="comment in codemaoComments" :key="comment.id" class="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition border-l-4 border-l-orange-200">
            <div class="flex items-start justify-between mb-3">
              <div class="flex items-center space-x-3">
                <img :src="comment.user.avatar_url || 'https://via.placeholder.com/40'" class="w-10 h-10 rounded-full border border-gray-100">
                <div>
                  <div class="font-bold text-gray-900">{{ comment.user.nickname }}</div>
                  <div class="text-xs text-gray-400">{{ new Date(comment.created_at * 1000).toLocaleDateString() }}</div>
                </div>
              </div>
            </div>
            <div class="prose prose-sm max-w-none text-gray-700 leading-relaxed" v-html="comment.content"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
