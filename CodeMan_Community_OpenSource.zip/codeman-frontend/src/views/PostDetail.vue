<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRoute } from 'vue-router'
import axios from 'axios'
import { authState } from '../store'
import { marked } from 'marked'
import DOMPurify from 'dompurify'
import MarkdownEditor from '../components/MarkdownEditor.vue'

const route = useRoute()
const post = ref(null)
const comments = ref([])
const loading = ref(true)
const error = ref('')
const replyContent = ref('')
const submitting = ref(false)

const showEmbed = ref(false)
const embedCode = computed(() => {
  if (!post.value) return ''
  // Use backend URL directly or proxy URL
  // For dev environment, using the window.location.origin (frontend) which proxies to backend
  const url = `${window.location.origin}/api/posts/${post.value.id}/embed`
  return `<iframe src="${url}" width="100%" height="600" frameborder="0" allowfullscreen></iframe>`
})

const copyEmbedCode = () => {
  navigator.clipboard.writeText(embedCode.value)
  alert('Embed code copied to clipboard!')
}

const parsedContent = computed(() => {
  if (!post.value || !post.value.content) return ''
  
  // Basic markdown-like parsing
  // 1. Link parsing: [text](url)
  let html = post.value.content.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" class="text-blue-600 hover:underline">$1</a>')
  
  // 2. Work Mention parsing: #work:12345
  html = html.replace(/#work:(\d+)/g, '<a href="/work/$1" class="text-purple-600 font-bold hover:underline">🎮 Work #$1</a>')
  
  // 3. Line breaks
  return html.replace(/\n/g, '<br>')
})


const fetchPost = async () => {
  loading.value = true
  try {
    const res = await axios.get(`/api/posts/${route.params.id}`)
    post.value = res.data
    
    // Fetch comments
    try {
      const commentsRes = await axios.get(`/api/posts/${route.params.id}/comments`)
      comments.value = commentsRes.data
    } catch (commentErr) {
      console.error("Failed to fetch comments", commentErr)
    }
    
  } catch (e) {
    error.value = "Failed to load post. It might have been deleted."
    console.error(e)
  } finally {
    loading.value = false
  }
}

const renderMarkdown = (text) => {
  if (!text) return ''
  
  // Pre-process [work:ID] to links for comments
  const processed = text.replace(/\[work:(\d+)\]/g, '[CodeMan Work $1](https://shequ.codemao.cn/work/$1)')

  // marked.parse is synchronous
  const html = marked.parse(processed)
  return DOMPurify.sanitize(html)
}

const submitComment = async () => {
  if (!replyContent.value.trim()) return
  
  const token = authState.token || localStorage.getItem('token')
  if (!token) {
    alert("Please login first")
    return
  }

  submitting.value = true
  try {
    const res = await axios.post(`/api/posts/${route.params.id}/comments`, {
      content: replyContent.value
    }, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })
    
    // Add new comment to list
    comments.value.unshift(res.data)
    replyContent.value = ''
  } catch (e) {
    alert("Failed to post comment: " + (e.response?.data?.detail || e.message))
  } finally {
    submitting.value = false
  }
}

onMounted(() => {
  fetchPost()
})
</script>

<template>
  <div class="container mx-auto px-4 py-8 max-w-4xl">
    <div v-if="loading" class="text-center py-12 text-gray-500">
      Loading discussion...
    </div>

    <div v-else-if="error" class="bg-red-50 text-red-600 p-8 rounded-xl text-center">
      {{ error }}
      <div class="mt-4">
        <router-link to="/forum" class="text-blue-600 hover:underline font-bold">Back to Forum</router-link>
      </div>
    </div>

    <div v-else class="space-y-6">
      <!-- Breadcrumb -->
      <nav class="text-sm text-gray-500 mb-4">
        <router-link to="/" class="hover:text-blue-600">Home</router-link>
        <span class="mx-2">/</span>
        <router-link to="/forum" class="hover:text-blue-600">Forum</router-link>
        <span class="mx-2">/</span>
        <span class="text-gray-900 truncate">{{ post.title }}</span>
      </nav>

      <!-- Main Post -->
      <article class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="p-8">
          <div class="flex items-center space-x-4 mb-6">
            <router-link :to="`/user/${post.user.id}`">
              <img :src="post.user.avatar_url || 'https://via.placeholder.com/48'" class="w-12 h-12 rounded-full border border-gray-200 hover:opacity-80 transition" alt="Avatar">
            </router-link>
            <div>
              <router-link :to="`/user/${post.user.id}`" class="font-bold text-gray-900 text-lg hover:text-blue-600 transition">{{ post.user.username }}</router-link>
              <div class="text-sm text-gray-500">
                Posted on {{ new Date(post.created_at).toLocaleString() }}
                <span v-if="post.category_id" class="ml-2 px-2 py-0.5 bg-gray-100 rounded-full text-xs">Category {{ post.category_id }}</span>
              </div>
            </div>
          </div>

          <h1 class="text-3xl font-extrabold text-gray-900 mb-6">{{ post.title }}</h1>
          
          <!-- Post Content -->
          <div class="prose prose-lg max-w-none text-gray-800 leading-relaxed mb-8" v-html="parsedContent">
          </div>
        </div>
        
        <!-- Action Bar -->
        <div class="bg-gray-50 px-8 py-4 border-t border-gray-100 flex items-center justify-between text-sm text-gray-600">
          <div class="flex space-x-6">
            <button class="flex items-center space-x-2 hover:text-blue-600 transition">
              <span>👍</span>
              <span>{{ post.likes }} Likes</span>
            </button>
            <div class="flex items-center space-x-2">
              <span>👁️</span>
              <span>{{ post.views }} Views</span>
            </div>
          </div>
          <div class="flex space-x-4">
            <button @click="showEmbed = !showEmbed" class="text-gray-500 hover:text-blue-600 font-medium">Embed</button>
            <button class="text-gray-500 hover:text-red-600">Report</button>
          </div>
        </div>

        <!-- Embed Code Section -->
        <div v-if="showEmbed" class="bg-gray-100 px-8 py-4 border-t border-gray-200 animate-fade-in-down">
          <p class="text-xs text-gray-500 mb-2 uppercase tracking-wide font-bold">Embed Code</p>
          <div class="flex items-center space-x-2">
            <input 
              readonly 
              :value="embedCode" 
              class="flex-1 p-2 border border-gray-300 rounded text-sm font-mono text-gray-600 bg-white focus:ring-2 focus:ring-blue-500 outline-none"
              @click="$event.target.select()"
            >
            <button @click="copyEmbedCode" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm font-medium transition">Copy</button>
          </div>
        </div>
      </article>

      <!-- Comments Section -->
      <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
        <h3 class="text-xl font-bold text-gray-900 mb-6">Comments ({{ comments.length }})</h3>
        
        <div v-if="comments.length === 0" class="text-center py-8 text-gray-500 bg-gray-50 rounded-lg border border-dashed border-gray-200">
          No comments yet. Be the first to share your thoughts!
        </div>

        <div v-else class="space-y-6 mb-8">
          <div v-for="comment in comments" :key="comment.id" class="flex space-x-4 p-4 bg-gray-50 rounded-lg">
            <router-link :to="`/user/${comment.user.id}`">
              <img :src="comment.user.avatar_url || 'https://via.placeholder.com/40'" class="w-10 h-10 rounded-full border border-gray-200 hover:opacity-80 transition" alt="Avatar">
            </router-link>
            <div class="flex-1">
              <div class="flex justify-between items-baseline mb-1">
                <router-link :to="`/user/${comment.user.id}`" class="font-bold text-gray-900 hover:text-blue-600 transition">{{ comment.user.username }}</router-link>
                <span class="text-xs text-gray-500">{{ new Date(comment.created_at).toLocaleString() }}</span>
              </div>
              <div 
                class="prose prose-sm max-w-none text-gray-700"
                v-html="renderMarkdown(comment.content)"
              ></div>
            </div>
          </div>
        </div>

        <!-- Reply Box -->
        <div v-if="authState.isAuthenticated" class="mt-8 relative z-10 pb-10">
          <MarkdownEditor 
            v-model="replyContent" 
            height="200px" 
            placeholder="Write a comment..." 
          />
          <div class="flex justify-end items-center mt-4">
            <button 
              @click="submitComment" 
              :disabled="submitting || !replyContent.trim()"
              class="px-6 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed shadow-md active:scale-95 touch-manipulation"
            >
              {{ submitting ? 'Posting...' : 'Post Comment' }}
            </button>
          </div>
        </div>
        <div v-else class="mt-8 text-center bg-blue-50 p-6 rounded-lg">
          <p class="text-blue-800 mb-2">Please log in to join the discussion.</p>
          <router-link to="/login" class="inline-block px-6 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition">Log In</router-link>
        </div>
      </div>
    </div>
  </div>
</template>
