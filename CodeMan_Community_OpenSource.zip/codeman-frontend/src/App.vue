<script setup>
import { RouterLink, RouterView } from 'vue-router'
import NavBar from './components/NavBar.vue'
import { authState, logout } from './store'
import { useRouter } from 'vue-router'
import { useI18n } from './i18n'

const router = useRouter()
const { t, locale, setLocale } = useI18n()

const handleRelogin = () => {
  authState.showLoginModal = false
  logout()
  router.push('/login')
}

const handleCancelLogin = () => {
  authState.showLoginModal = false
  logout() // Still logout because token is invalid
}

const toggleLang = () => {
  setLocale(locale.value === 'zh' ? 'en' : 'zh')
}
</script>

<template>
  <div class="min-h-screen bg-gray-50 text-gray-900 font-sans flex flex-col">
    <NavBar />
    <main class="container mx-auto px-4 py-8 flex-grow">
      <RouterView />
    </main>
    <footer class="bg-white border-t border-gray-200 mt-12 py-8 text-center text-sm text-gray-500">
      <div class="flex flex-col items-center space-y-4">
        <p>{{ t('common.footerCopyright') }}</p>
        <button 
          @click="toggleLang"
          class="px-4 py-1.5 border border-gray-300 rounded-full hover:bg-gray-50 transition text-xs flex items-center space-x-2"
        >
          <span>🌐</span>
          <span>{{ locale === 'zh' ? 'English' : '中文' }}</span>
        </button>
      </div>
    </footer>

    <!-- Session Expired Modal -->
    <div v-if="authState.showLoginModal" class="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div class="absolute inset-0 bg-black/60 backdrop-blur-sm"></div>
      <div class="bg-white rounded-xl shadow-2xl w-full max-w-sm relative z-10 p-6 text-center transform scale-100 transition-all">
        <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
        </div>
        <h3 class="text-xl font-bold text-gray-900 mb-2">{{ t('common.sessionExpired') }}</h3>
        <p class="text-gray-500 mb-6">{{ t('common.sessionExpiredDesc') }}</p>
        
        <div class="flex space-x-3">
          <button @click="handleCancelLogin" class="flex-1 px-4 py-2 border border-gray-300 text-gray-700 font-bold rounded-lg hover:bg-gray-50 transition">
            {{ t('common.later') }}
          </button>
          <button @click="handleRelogin" class="flex-1 px-4 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition shadow-lg">
            {{ t('common.loginNow') }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
