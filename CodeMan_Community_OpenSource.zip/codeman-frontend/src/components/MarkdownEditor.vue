<script setup>
import { ref, watch, computed } from 'vue'
import { marked } from 'marked'
import DOMPurify from 'dompurify'

const props = defineProps({
  modelValue: {
    type: String,
    default: ''
  },
  placeholder: {
    type: String,
    default: 'Write your content here...'
  },
  height: {
    type: String,
    default: '300px'
  }
})

const emit = defineEmits(['update:modelValue'])

const content = ref(props.modelValue)
const isPreview = ref(false)
const textareaRef = ref(null)

watch(() => props.modelValue, (val) => {
  content.value = val
})

watch(content, (val) => {
  emit('update:modelValue', val)
})

const parsedContent = computed(() => {
  // Pre-process [work:ID] to placeholders
  const text = (content.value || '').replace(/\[work:(\d+)\]/g, '**(Work Card: $1)**')
  const html = marked(text)
  return DOMPurify.sanitize(html)
})

const insertText = (before, after = '') => {
  const textarea = textareaRef.value
  if (!textarea) return

  const start = textarea.selectionStart
  const end = textarea.selectionEnd
  const selectedText = content.value.substring(start, end)
  const replacement = before + selectedText + after
  
  content.value = content.value.substring(0, start) + replacement + content.value.substring(end)
  
  // Restore focus and selection
  setTimeout(() => {
    textarea.focus()
    textarea.setSelectionRange(start + before.length, end + before.length)
  }, 0)
}

const insertLink = () => {
  insertText('[', '](url)')
}

const insertImage = () => {
  insertText('![alt text](', ')')
}

const insertWork = () => {
  const id = prompt('Enter Codemao Work ID:')
  if (id && /^\d+$/.test(id)) {
    insertText(`[work:${id}]`)
  } else if (id) {
    alert('Invalid Work ID')
  }
}

const toolbarItems = [
  { icon: 'B', label: 'Bold', action: () => insertText('**', '**') },
  { icon: 'I', label: 'Italic', action: () => insertText('*', '*') },
  { icon: 'H', label: 'Heading', action: () => insertText('### ') },
  { icon: 'List', label: 'List', action: () => insertText('- ') },
  { icon: 'Code', label: 'Code', action: () => insertText('`', '`') },
  { icon: 'Link', label: 'Link', action: insertLink },
  { icon: 'Image', label: 'Image', action: insertImage },
  { icon: '🎮', label: 'Work', action: insertWork, title: 'Embed Codemao Work' },
]
</script>

<template>
  <div class="border border-gray-300 rounded-lg overflow-hidden bg-white flex flex-col transition-shadow focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-blue-500">
    <!-- Toolbar -->
    <div class="flex items-center justify-between border-b border-gray-200 bg-gray-50 px-2 py-1.5">
      <div class="flex items-center space-x-1">
        <button 
          v-for="(item, index) in toolbarItems" 
          :key="index"
          @click="item.action"
          class="p-1.5 text-gray-600 hover:text-blue-600 hover:bg-gray-200 rounded transition"
          :title="item.title || item.label"
        >
          <span class="text-sm font-bold w-5 h-5 flex items-center justify-center">{{ item.icon }}</span>
        </button>
      </div>
      
      <div class="flex items-center space-x-2 text-xs">
        <button 
          @click="isPreview = false"
          class="px-3 py-1 rounded-full transition"
          :class="!isPreview ? 'bg-white text-blue-600 shadow-sm font-medium' : 'text-gray-500 hover:text-gray-700'"
        >
          Write
        </button>
        <button 
          @click="isPreview = true"
          class="px-3 py-1 rounded-full transition"
          :class="isPreview ? 'bg-white text-blue-600 shadow-sm font-medium' : 'text-gray-500 hover:text-gray-700'"
        >
          Preview
        </button>
      </div>
    </div>

    <!-- Editor Area -->
    <div class="relative flex-1 bg-white">
      <textarea
        v-show="!isPreview"
        ref="textareaRef"
        v-model="content"
        :style="{ height: height }"
        class="w-full p-4 outline-none resize-y font-mono text-sm leading-relaxed md:text-sm text-base"
        :placeholder="placeholder"
      ></textarea>
      
      <div 
        v-show="isPreview"
        :style="{ height: height }"
        class="w-full p-4 overflow-y-auto prose prose-sm max-w-none bg-gray-50"
        v-html="parsedContent"
      ></div>
    </div>
    
    <div class="bg-gray-50 px-3 py-1.5 border-t border-gray-200 text-xs text-gray-400 flex justify-between">
      <span>Markdown Supported</span>
      <a href="https://www.markdownguide.org/basic-syntax/" target="_blank" class="hover:text-blue-500">Syntax Guide</a>
    </div>
  </div>
</template>
