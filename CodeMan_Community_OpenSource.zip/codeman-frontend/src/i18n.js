
import { reactive, computed, watch } from 'vue'

const savedLang = localStorage.getItem('app_lang') || 'zh'

export const i18nState = reactive({
  locale: savedLang
})

export function setLocale(lang) {
  i18nState.locale = lang
  localStorage.setItem('app_lang', lang)
}

const messages = {
  zh: {
    common: {
      home: '首页',
      forum: '论坛',
      showcase: '作品展示',
      about: '关于我们',
      login: '登录',
      logout: '退出登录',
      profile: '个人主页',
      loading: '加载中...',
      loadMore: '加载更多',
      noMore: '已经到底啦~',
      views: '浏览',
      likes: '点赞',
      download: '下载',
      post: '帖子',
      joinDiscussion: '加入讨论',
      exploreProjects: '探索项目',
      welcome: '欢迎来到 CodeMan',
      welcomeDesc: '新一代创意编程社区。安全、快速、开放。',
      trending: '热门趋势',
      hotDiscuss: '热门讨论',
      hotWorks: '热门作品',
      recentDiscuss: '最新讨论',
      viewForum: '查看论坛',
      featuredWorks: '精选作品',
      viewShowcase: '查看展示',
      noDiscussions: '暂无讨论，快来发布第一条吧！',
      slogan: '连接每位开发者',
      mission: '缔造更好猫站，为编程猫用户打造的安全、自由、开放的交流社区。',
      featureSource: '特色源码分享',
      featureSourceDesc: '汇聚优质编程猫作品源码，促进技术交流与学习，让知识自由流动。',
      featureSafe: '安全浏览体验',
      featureSafeDesc: '内置防 XSS 攻击机制，过滤恶意代码，为所有年龄段用户提供纯净的浏览环境。',
      featureApi: '开放 API 接口',
      featureApiDesc: '面向全体编程猫用户提供安全、稳定的 API 接口，赋能开发者创造更多可能。',
      team: '维护团队',
      maintainer: 'CodeMan Community 由 Skyworld 全权维护。',
      devService: '开发者服务',
      devServiceDesc: '我们提供编程猫统一登录平台接入方案，支持 iframe + SDK 快速集成。',
      ack: '特别致谢',
      loginTitle: '账号登录',
      loginSubtitle: '请使用编程猫社区账号继续',
      usernameLabel: '账号 / 手机号',
      passwordLabel: '密码',
      usernamePlaceholder: '请输入编程猫账号',
      passwordPlaceholder: '请输入密码',
      submitLogin: '授权并登录',
      loggingIn: '正在验证...',
      forgotPassword: '忘记密码? 请前往编程猫官网找回',
      authTitle: '开发者授权',
      authRequest: 'CodeMan Community 请求访问您的账户信息。',
      authScope: '此操作将允许该应用获取您的公开资料（昵称、头像、简介等）。',
      scopeProfile: '读取用户公开资料',
      scopePost: '发布帖子与评论',
      sessionExpired: '会话已过期',
      sessionExpiredDesc: '您的登录状态已失效，请重新登录以继续。',
      later: '稍后',
      loginNow: '立即登录',
      footerCopyright: '© 2026 CodeMan Community. 为编程猫开发者而生。',
      switchLang: 'Language / 语言'
    }
  },
  en: {
    common: {
      home: 'Home',
      forum: 'Forum',
      showcase: 'Showcase',
      about: 'About Us',
      login: 'Log In',
      logout: 'Log Out',
      profile: 'My Profile',
      loading: 'Loading...',
      loadMore: 'Load More',
      noMore: 'No more data',
      views: 'Views',
      likes: 'Likes',
      download: 'Download',
      post: 'Post',
      joinDiscussion: 'Join Discussion',
      exploreProjects: 'Explore Projects',
      welcome: 'Welcome to CodeMan',
      welcomeDesc: 'The next-generation community for creative coders. Secure, fast, and open.',
      trending: 'Trending Now',
      hotDiscuss: 'Hot Discussions',
      hotWorks: 'Popular Works',
      recentDiscuss: 'Recent Discussions',
      viewForum: 'View Forum',
      featuredWorks: 'Featured Works',
      viewShowcase: 'View Showcase',
      noDiscussions: 'No discussions yet. Be the first to post!',
      slogan: 'Connecting Every Developer',
      mission: 'Building a better Codemao site. A secure, free, and open community for all Codemao users.',
      featureSource: 'Source Code Sharing',
      featureSourceDesc: 'Gathering high-quality Codemao project source codes to promote technical exchange and learning.',
      featureSafe: 'Safe Browsing',
      featureSafeDesc: 'Built-in Anti-XSS mechanism to filter malicious code, providing a clean environment for users of all ages.',
      featureApi: 'Open API',
      featureApiDesc: 'Providing secure and stable API interfaces for all Codemao users, empowering developers to create more.',
      team: 'Maintainer Team',
      maintainer: 'CodeMan Community is maintained by Skyworld.',
      devService: 'Developer Services',
      devServiceDesc: 'We provide Codemao Unified Login Platform integration, supporting iframe + SDK quick integration.',
      ack: 'Special Thanks',
      loginTitle: 'Account Login',
      loginSubtitle: 'Please continue with your Codemao account',
      usernameLabel: 'Username / Phone',
      passwordLabel: 'Password',
      usernamePlaceholder: 'Enter Codemao ID',
      passwordPlaceholder: 'Enter Password',
      submitLogin: 'Authorize & Login',
      loggingIn: 'Verifying...',
      forgotPassword: 'Forgot Password? Reset at Codemao Official Site',
      authTitle: 'Developer Authorization',
      authRequest: 'CodeMan Community requests access to your account info.',
      authScope: 'This will allow the app to access your public profile (nickname, avatar, bio, etc).',
      scopeProfile: 'Read Public Profile',
      scopePost: 'Publish Posts & Comments',
      sessionExpired: 'Session Expired',
      sessionExpiredDesc: 'Your login session has expired. Please log in again to continue.',
      later: 'Later',
      loginNow: 'Log In Now',
      footerCopyright: '© 2026 CodeMan Community. Built for Codemao Developers.',
      switchLang: 'Language / 语言'
    }
  }
}

export function t(key) {
  const keys = key.split('.')
  let value = messages[i18nState.locale]
  for (const k of keys) {
    if (value && value[k]) {
      value = value[k]
    } else {
      return key // Fallback to key if not found
    }
  }
  return value
}

// Composable for use in components
export function useI18n() {
  return {
    t,
    locale: computed(() => i18nState.locale),
    setLocale
  }
}
