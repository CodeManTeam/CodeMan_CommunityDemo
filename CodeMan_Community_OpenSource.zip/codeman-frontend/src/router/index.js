import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import Login from '../views/Login.vue'
import Forum from '../views/Forum.vue'
import Showcase from '../views/Showcase.vue'
import PostDetail from '../views/PostDetail.vue'
import UserProfile from '../views/UserProfile.vue'
import SearchResults from '../views/SearchResults.vue'
import WorkDetail from '../views/WorkDetail.vue'
import AdminBanner from '../views/AdminBanner.vue'
import BcmPostDetail from '../views/BcmPostDetail.vue'
import About from '../views/About.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/about',
      name: 'about',
      component: About
    },
    {
      path: '/forum/bcm/:id',
      name: 'bcm-post-detail',
      component: BcmPostDetail
    },
    {
      path: '/admin/banners',
      name: 'admin-banners',
      component: AdminBanner
    },
    {
      path: '/work/:id',
      name: 'work-detail',
      component: WorkDetail
    },
    {
      path: '/search',
      name: 'search-results',
      component: SearchResults
    },
    {
      path: '/login',
      name: 'login',
      component: Login
    },
    {
      path: '/forum',
      name: 'forum',
      component: Forum
    },
    {
      path: '/forum/:id',
      name: 'post-detail',
      component: PostDetail
    },
    {
      path: '/showcase',
      name: 'showcase',
      component: Showcase
    },
    {
      path: '/user/:id',
      name: 'user-profile',
      component: UserProfile
    }
  ]
})

export default router
