# CodeMan Community (Open Source Version)

CodeMan Community is a third-party community platform for Codemao developers. This repository contains the full source code for deployment.

## 🚀 Deployment

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/codeman-community.git
   cd codeman-community
   ```

2. **Start with Docker Compose**
   ```bash
   docker compose up -d --build
   ```

3. **Access the site**
   - Frontend: `http://localhost:80`
   - Backend API: `http://localhost:8000`

## 📂 Project Structure

- `codeman-backend/`: Python FastAPI backend
- `codeman-frontend/`: Vue 3 frontend

## 🛡️ Security Note

This open-source version does **not** include any private keys or production databases.
- `private_key.pem` and `database.db` are excluded.
- The system will automatically generate new keys upon first startup.

## 📄 Documentation

- [System Security Whitepaper](System_Security_Whitepaper.md)
- [Promotion Plan](Promotion_Plan.md)

---
*Maintained by CodeMan Community Team*
